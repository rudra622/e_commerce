import React from 'react'
import './product.css'
function Product() {
    return (
        <>
            <section>
                <div className='container'>
                    <div className='Product-haed col text-center'>
                        <h2>Man & Woman Fashion</h2>
                    </div>
                    <div className='row'>
                        <div className='col-4'>
                            <div className="box-main text-center">
                                <h4 className='shirt-text'>Man T-shirt</h4>
                                <p className='price-text'>price
                                <span>$30</span>
                                </p>
                                <div className='t-shirt-img'>
                                    <img src="./img/tshirt-img.png" alt="" />
                                </div>
                                <div className='btn-main d-flex justify-content-between'>
                                    <div className='buy-bt'><a href="" className='text-decoration-none' >buy now</a></div>
                                    <div className='seemore-bt'><a href="" className='text-decoration-none text-dark '>see more</a></div>
                                </div>
                            </div>
                        </div>
                        <div className='col-4'>
                            <div className="box-main text-center">
                                <h4 className='shirt-text'>Man T-shirt</h4>
                                <p className='price-text'>price
                                <span>$30</span>
                                </p>
                                <div className='t-shirt-img'>
                                    <img src="./img/tshirt-img.png" alt="" />
                                </div>
                                <div className='btn-main d-flex justify-content-between'>
                                    <div className='buy-bt'><a href="" className='text-decoration-none' >buy now</a></div>
                                    <div className='seemore-bt'><a href="" className='text-decoration-none text-dark '>see more</a></div>
                                </div>
                            </div>
                        </div>
                        <div className='col-4'>
                            <div className="box-main text-center">
                                <h4 className='shirt-text'>Man T-shirt</h4>
                                <p className='price-text'>price
                                <span>$30</span>
                                </p>
                                <div className='t-shirt-img'>
                                    <img src="./img/tshirt-img.png" alt="" />
                                </div>
                                <div className='btn-main d-flex justify-content-between'>
                                    <div className='buy-bt'><a href="" className='text-decoration-none' >buy now</a></div>
                                    <div className='seemore-bt'><a href="" className='text-decoration-none text-dark '>see more</a></div>
                                </div>
                            </div>
                        </div>
                        <div className='col-4'>
                            <div className="box-main text-center">
                                <h4 className='shirt-text'>Man T-shirt</h4>
                                <p className='price-text'>price
                                <span>$30</span>
                                </p>
                                <div className='t-shirt-img'>
                                    <img src="./img/tshirt-img.png" alt="" />
                                </div>
                                <div className='btn-main d-flex justify-content-between'>
                                    <div className='buy-bt'><a href="" className='text-decoration-none' >buy now</a></div>
                                    <div className='seemore-bt'><a href="" className='text-decoration-none text-dark '>see more</a></div>
                                </div>
                            </div>
                        </div>
                        <div className='col-4'>
                            <div className="box-main text-center">
                                <h4 className='shirt-text'>Man T-shirt</h4>
                                <p className='price-text'>price
                                <span>$30</span>
                                </p>
                                <div className='t-shirt-img'>
                                    <img src="./img/tshirt-img.png" alt="" />
                                </div>
                                <div className='btn-main d-flex justify-content-between'>
                                    <div className='buy-bt'><a href="" className='text-decoration-none' >buy now</a></div>
                                    <div className='seemore-bt'><a href="" className='text-decoration-none text-dark '>see more</a></div>
                                </div>
                            </div>
                        </div>
                        <div className='col-4'>
                            <div className="box-main text-center">
                                <h4 className='shirt-text'>Man T-shirt</h4>
                                <p className='price-text'>price
                                <span>$30</span>
                                </p>
                                <div className='t-shirt-img'>
                                    <img src="./img/tshirt-img.png" alt="" />
                                </div>
                                <div className='btn-main d-flex justify-content-between'>
                                    <div className='buy-bt'><a href="" className='text-decoration-none' >buy now</a></div>
                                    <div className='seemore-bt'><a href="" className='text-decoration-none text-dark '>see more</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default Product