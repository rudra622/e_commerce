import Header from "./component/Header/Header";
import Product from "./component/Product/Product";
import Slider from "./component/slider/Slider";

function App() {
  return (
    <>
    <Header/>
    <Slider/>
    <Product/>
    </>
  );
}

export default App;
