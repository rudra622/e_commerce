import React from 'react'
import { Dribbble, Facebook, Instagram, PhoneFill, Search, TelephoneFill, Twitter } from 'react-bootstrap-icons'
import './Header.css'

function Header() {
    return (
        <>
            <header>
                <div className="wrap bg-dark">
                    <div className="container">
                        <div className="row justify-content-between align-items-center">
                            <div className="col">
                                <p className="mb-0 phone"><TelephoneFill className='text-secondary' /> <a href="#" className='text-decoration-none'>+00 1234 567</a></p>
                            </div>
                            <div className="col d-flex justify-content-end">
                                <div className="social-media">
                                    <p className="mb-0 d-flex">
                                        <a href="#" className="d-flex align-items-center justify-content-center"><Facebook /></a>
                                        <a href="#" className="d-flex align-items-center justify-content-center"><Twitter /></a>
                                        <a href="#" className="d-flex align-items-center justify-content-center"><Instagram /></a>
                                        <a href="#" className="d-flex align-items-center justify-content-center"><Dribbble /></a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <nav className="navbar navbar-expand-lg navbar-dark  border-bottom shadow">
                    <div className="container">
                        <a className="navbar-brand text-dark" href="">E-commerce</a>
                        <form className="searchform order-sm-start order-lg-last">
                            <div className="form-group d-flex">
                                <input type="text" className="form-control pl-3" placeholder="Search" />
                                <button type="submit" placeholder className="form-control search"><Search /></button>
                            </div>
                        </form>
                        {/* <button className="navbar-toggler" type="button">
                            <span className="fa fa-bars" /> Menu
                        </button> */}
                        <div className="collapse navbar-collapse">
                            <ul className="navbar-nav m-auto">
                                <li className="nav-item active">
                                    <a href="#" className="nav-link text-dark">Home</a>
                                </li>
                                <li className="nav-item dropdown">
                                    <a className="nav-link dropdown-toggle text-dark" href="#">Page</a>
                                    <ul className="dropdown-menu">
                                        <li>
                                            <a className="dropdown-item text-dark" href="#">Page 1</a>
                                        </li>
                                        <li>
                                            <a className="dropdown-item text-dark" href="#">Page 2</a>
                                        </li>
                                        <li>
                                            <a className="dropdown-item text-dark" href="#">Page 3</a>
                                        </li>
                                        <li>
                                            <a className="dropdown-item text-dark" href="#">Page 4</a>
                                        </li>
                                    </ul>
                                </li>
                                <li className="nav-item">
                                    <a href="#" className="nav-link text-dark">Catalog</a>
                                </li>
                                <li className="nav-item">
                                    <a href="#" className="nav-link text-dark">Blog</a>
                                </li>
                                <li className="nav-item">
                                    <a href="#" className="nav-link text-dark">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>

            </header>

        </>
    )
}

export default Header